/* main.js — shared UI utilities */

// Close modal when clicking outside
document.addEventListener("click", function (e) {
  const overlay = document.getElementById("new-session-modal");
  if (overlay && e.target === overlay) {
    overlay.style.display = "none";
  }
});
