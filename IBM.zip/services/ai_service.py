"""
AI service — IBM watsonx.ai Granite foundation model.

Uses the ibm-watsonx-ai SDK (ibm_watsonx_ai.foundation_models).
For every user message the service:
  1. Builds a structured mentor prompt from conversation history.
  2. Calls the Granite model via the watsonx.ai text-generation endpoint.
  3. Parses the model output into five mentor sections:
       • Problem Identification
       • Technology Suggestions
       • Required Components
       • Innovation Improvements
       • Development Roadmap
  4. Falls back to returning the raw text if parsing is not applicable
     (e.g. clarifying questions, follow-ups).
"""

from __future__ import annotations

import logging
import re
from typing import List, Dict

from flask import current_app

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Section headers the Granite model is instructed to use
# ---------------------------------------------------------------------------
SECTION_LABELS = [
    "PROBLEM IDENTIFICATION",
    "TECHNOLOGY SUGGESTIONS",
    "REQUIRED COMPONENTS",
    "INNOVATION IMPROVEMENTS",
    "DEVELOPMENT ROADMAP",
]


class AIService:
    """Stateless wrapper around the IBM watsonx.ai Granite chat/generation API."""

    # -----------------------------------------------------------------------
    # Stage-specific context injected into every prompt
    # -----------------------------------------------------------------------
    STAGE_HINTS: Dict[str, str] = {
        "ideation": (
            "The user is in the IDEATION stage. "
            "Focus on expanding thinking, questioning assumptions, "
            "and exploring problem-market fit."
        ),
        "prototype": (
            "The user is in the PROTOTYPING stage. "
            "Focus on MVP scope, technical feasibility, "
            "feedback loops, and rapid iteration."
        ),
        "scale": (
            "The user is in the SCALING stage. "
            "Focus on growth levers, operational efficiency, "
            "team building, and metric-driven decisions."
        ),
    }

    # -----------------------------------------------------------------------
    # Structured-analysis trigger: use this prompt when the user describes
    # an idea (first message or when the history is short).
    # -----------------------------------------------------------------------
    ANALYSIS_INSTRUCTION = """
You are Aria, an expert AI Innovation Mentor powered by IBM Granite.
Analyse the user's idea and respond with EXACTLY the following five sections
(use the headers verbatim, in ALL CAPS, followed by a colon):

PROBLEM IDENTIFICATION:
<Identify the core problem the idea addresses. Be specific and concise.>

TECHNOLOGY SUGGESTIONS:
<List 3-5 relevant AI/ML technologies, frameworks, or IBM tools that fit this idea.>

REQUIRED COMPONENTS:
<List the key technical and non-technical components needed to build this solution.>

INNOVATION IMPROVEMENTS:
<Suggest 2-3 ways the idea can be made more innovative or impactful.>

DEVELOPMENT ROADMAP:
<Provide a concise phased roadmap: Phase 1 (weeks 1-4), Phase 2 (weeks 5-10), Phase 3 (weeks 11+).>

Be concise, actionable, and encouraging. Use plain text (no markdown).
""".strip()

    # -----------------------------------------------------------------------
    # Conversational follow-up prompt (after the first exchange)
    # -----------------------------------------------------------------------
    FOLLOWUP_INSTRUCTION = """
You are Aria, an expert AI Innovation Mentor powered by IBM Granite.
Continue the conversation. Ask clarifying questions, challenge assumptions
constructively, suggest frameworks (e.g. Jobs-to-be-Done, Design Thinking),
and recommend concrete next steps. Be concise, encouraging, and actionable.
If the user asks for a full analysis, use the five-section structured format:
PROBLEM IDENTIFICATION, TECHNOLOGY SUGGESTIONS, REQUIRED COMPONENTS,
INNOVATION IMPROVEMENTS, DEVELOPMENT ROADMAP.
""".strip()

    # -----------------------------------------------------------------------
    # Public API (matches the signature expected by routes/mentor.py)
    # -----------------------------------------------------------------------
    def get_response(self, history: List[Dict[str, str]], stage: str = "ideation") -> str:
        """
        Generate an AI mentor response using IBM watsonx.ai Granite.

        :param history:  Full conversation so far as a list of
                         {"role": "user"|"assistant", "content": "..."} dicts.
                         The last entry is always the newest user message.
        :param stage:    Current innovation stage (ideation | prototype | scale).
        :returns:        Formatted mentor reply string.
        """
        cfg = current_app.config

        api_key    = cfg.get("WATSONX_API_KEY", "")
        project_id = cfg.get("WATSONX_PROJECT_ID", "")
        url        = cfg.get("WATSONX_URL", "https://us-south.ml.cloud.ibm.com")

        if not api_key or not project_id:
            return (
                "AI service unavailable — WATSONX_API_KEY and WATSONX_PROJECT_ID "
                "must be set in your .env file."
            )

        try:
            from ibm_watsonx_ai import APIClient, Credentials
            from ibm_watsonx_ai.foundation_models import ModelInference
            from ibm_watsonx_ai.metanames import GenTextParamsMetaNames as GenParams
        except ImportError:
            logger.error("ibm-watsonx-ai package not installed. Run: pip install ibm-watsonx-ai")
            return "AI service unavailable — ibm-watsonx-ai package not installed."

        # ----------------------------------------------------------------
        # Choose instruction block based on conversation depth
        # ----------------------------------------------------------------
        user_turns = sum(1 for m in history if m["role"] == "user")
        is_first_idea = user_turns <= 1
        instruction = (
            self.ANALYSIS_INSTRUCTION if is_first_idea else self.FOLLOWUP_INSTRUCTION
        )

        stage_hint = self.STAGE_HINTS.get(stage, "")
        prompt = self._build_prompt(instruction, stage_hint, history)

        # ----------------------------------------------------------------
        # Watsonx.ai model call
        # ----------------------------------------------------------------
        try:
           credentials = Credentials(
    url=url,
    api_key=api_key
)

client = APIClient(credentials)

# Set the project after creating the client
client.set.default_project(project_id)

model = ModelInference(
    model_id=cfg.get("WATSONX_MODEL_ID", "ibm/granite-13b-instruct-v2"),
    api_client=client,
)

            params = {
                GenParams.MAX_NEW_TOKENS: cfg.get("AI_MAX_TOKENS", 1024),
                GenParams.MIN_NEW_TOKENS: 50,
                GenParams.TEMPERATURE:    0.7,
                GenParams.TOP_P:          0.9,
                GenParams.REPETITION_PENALTY: 1.1,
                GenParams.STOP_SEQUENCES: ["Human:", "User:"],
            }

            result = model.generate_text(prompt=prompt, params=params)
            raw_text = result.strip() if isinstance(result, str) else str(result).strip()

        except Exception as exc:
            logger.exception("watsonx.ai API error: %s", exc)
            return f"I encountered an issue reaching IBM watsonx.ai: {exc}"

        # ----------------------------------------------------------------
        # Post-process: format structured sections if present
        # ----------------------------------------------------------------
        return self._format_response(raw_text)

    # -----------------------------------------------------------------------
    # Private helpers
    # -----------------------------------------------------------------------
    def _build_prompt(
        self,
        instruction: str,
        stage_hint: str,
        history: List[Dict[str, str]],
    ) -> str:
        """Assemble the full text prompt for Granite."""
        lines: List[str] = [instruction]
        if stage_hint:
            lines += ["", f"[Context: {stage_hint}]"]
        lines.append("")
        for msg in history:
            role = "User" if msg["role"] == "user" else "Aria"
            lines.append(f"{role}: {msg['content']}")
        lines += ["", "Aria:"]
        return "\n".join(lines)

    def _format_response(self, text: str) -> str:
        """
        If the model returned all five structured sections, reformat them
        with clear visual separators. Otherwise return the raw text as-is.
        """
        found = [lbl for lbl in SECTION_LABELS if lbl in text.upper()]
        if len(found) < 3:          # not a structured response — return as-is
            return text

        output_parts: List[str] = []
        # Split on any of the section headers (case-insensitive)
        pattern = r"(?i)(" + "|".join(re.escape(lbl) for lbl in SECTION_LABELS) + r")\s*:"
        segments = re.split(pattern, text, flags=re.IGNORECASE)

        # segments alternates: [preamble, HEADER, body, HEADER, body, ...]
        i = 1
        while i < len(segments) - 1:
            header = segments[i].strip().upper()
            body   = segments[i + 1].strip()
            output_parts.append(f"▸ {header}\n{body}")
            i += 2

        return "\n\n".join(output_parts) if output_parts else text
